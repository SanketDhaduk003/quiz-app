import backIcon from '../images/back-icon.svg'
import forwardIcon from '../images/forward-icon.svg'


export  {
    backIcon, 
    forwardIcon
}