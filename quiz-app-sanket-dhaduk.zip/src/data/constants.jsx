const optionsLabels = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];

export {
    optionsLabels
}